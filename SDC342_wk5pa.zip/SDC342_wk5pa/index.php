<?php
// index.php
?>
<!DOCTYPE html>
<html>
<head>
    <title>DAMHAR2570 Wk5 Performance Assessment</title>
</head>
<body>
    <h1>DAMHAR2570 Wk5 Performance Assessment</h1>

    <nav>
        <ul>
            <li><a href="text_files.php">Text File Page</a></li>
            <li><a href="images.php">Images Page</a></li>
        </ul>
    </nav>
</body>
</html>
