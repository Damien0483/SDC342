<?php
class ImageUtilities {

    // Get list of base images (.png, .jpg, .jpeg)
    public static function GetBaseImagesList($dir) {
        $images = array();

        foreach (scandir($dir) as $file) {
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            if (
                is_file($dir . $file) &&
                (strtolower($ext) === 'png' ||
                 strtolower($ext) === 'jpg' ||
                 strtolower($ext) === 'jpeg')
            ) {
                $images[] = $file;
            }
        }
        return $images;
    }

    // Create resized image directories, if needed
    private static function CreateDirectories($dir) {
        $sizes = [100, 250, 500];
        foreach ($sizes as $size) {
            if (!file_exists($dir . '/' . $size)) {
                mkdir($dir . '/' . $size, 0777, true);
            }
        }
    }

    // Resize image to fit within max x max, keeping aspect ratio
    private static function ResizeImage($orig, $type, $max) {
        if ($type === IMAGETYPE_PNG) {
            $origImage = imagecreatefrompng($orig);
        } elseif ($type === IMAGETYPE_JPEG) {
            $origImage = imagecreatefromjpeg($orig);
        } else {
            return null;
        }

        $origWidth  = imagesx($origImage);
        $origHeight = imagesy($origImage);

        $ratioWidth  = $origWidth / $max;
        $ratioHeight = $origHeight / $max;
        $ratio       = max($ratioWidth, $ratioHeight);

        $newWidth  = round($origWidth / $ratio);
        $newHeight = round($origHeight / $ratio);

        $newImg = imagecreatetruecolor($newWidth, $newHeight);
        imagecopyresampled(
            $newImg,
            $origImage,
            0, 0, 0, 0,
            $newWidth, $newHeight,
            $origWidth, $origHeight
        );
        imagedestroy($origImage);

        return $newImg;
    }

    // Process an image file into 100, 250, 500 sizes
    public static function ProcessImage($file) {
        $fInfo   = pathinfo($file);
        $dir     = $fInfo['dirname'];
        $base    = $fInfo['basename'];

        self::CreateDirectories($dir);

        $imgInfo = getimagesize($file);
        $imgType = $imgInfo[2];

        $sizes = [100, 250, 500];

        foreach ($sizes as $size) {
            $newImg = self::ResizeImage($file, $imgType, $size);
            if ($newImg === null) {
                continue;
            }

            $targetFile = $dir . '/' . $size . '/' . $base;

            switch ($imgType) {
                case IMAGETYPE_PNG:
                    imagepng($newImg, $targetFile);
                    break;
                case IMAGETYPE_JPEG:
                    imagejpeg($newImg, $targetFile);
                    break;
            }

            imagedestroy($newImg);
        }
    }

    // Delete base and associated images
    public static function DeleteImageFiles($dir, $base) {
        $sizes = [100, 250, 500];

        // Delete base
        if (file_exists($dir . $base)) {
            unlink($dir . $base);
        }

        // Delete resized
        foreach ($sizes as $size) {
            $path = $dir . $size . '/' . $base;
            if (file_exists($path)) {
                unlink($path);
            }
        }
    }
}
