<?php
require_once __DIR__ . '/classes/FileUtilities.php';

$dir = __DIR__ . '/text_files/';

$viewFile = '';
$editFile = '';
$selectedViewFile = '';
$selectedEditFile = '';

// View file
if (isset($_POST['view'])) {
    $fName = $_POST['fileToView'] ?? '';
    if ($fName !== '') {
        $viewFile = FileUtilities::GetFileContents($dir . $fName);
        $selectedViewFile = $fName;
    }
}

// Load file for edit
if (isset($_POST['load'])) {
    $fName = $_POST['fileToUpdate'] ?? '';
    if ($fName !== '') {
        $editFile = FileUtilities::GetFileContents($dir . $fName);
        $selectedEditFile = $fName;
    }
}

// Save edited file
if (isset($_POST['save'])) {
    $fName   = $_POST['fileToUpdate'] ?? '';
    $content = $_POST['editFile'] ?? '';
    if ($fName !== '') {
        FileUtilities::WriteFile($dir . $fName, $content);
        $editFile = '';
        $selectedEditFile = '';
    }
}

// Create new file
if (isset($_POST['create'])) {
    $fName   = $_POST['newFileName'] ?? '';
    $content = $_POST['createFile'] ?? '';
    if ($fName !== '') {
        FileUtilities::WriteFile($dir . $fName, $content);
    }
}

$fileList = FileUtilities::GetFileList($dir);
?>
<!DOCTYPE html>
<html>
<head>
    <title>DAMHAR2570 Wk5 Performance Assessment</title>
</head>
<body>
    <h1>Text File Operations</h1>
    <p><a href="index.php">Home</a></p>

    <h3>Text Files Available:</h3>
    <ul>
        <?php foreach ($fileList as $file) : ?>
            <li><?php echo htmlspecialchars($file); ?></li>
        <?php endforeach; ?>
    </ul>

    <form method="POST">
        <h3>View Text File:</h3>
        <select name="fileToView">
            <?php foreach ($fileList as $file) : ?>
                <option value="<?php echo htmlspecialchars($file); ?>"
                    <?php if ($file === $selectedViewFile) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($file); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <input type="submit" value="View File" name="view">

        <br><br>
        <textarea name="viewFile" rows="5" cols="60" disabled><?php
            echo htmlspecialchars($viewFile);
        ?></textarea>

        <hr>

        <h3>Update Text File:</h3>
        <select name="fileToUpdate">
            <?php foreach ($fileList as $file) : ?>
                <option value="<?php echo htmlspecialchars($file); ?>"
                    <?php if ($file === $selectedEditFile) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($file); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <input type="submit" value="Load File" name="load">
        <input type="submit" value="Save" name="save">

        <br><br>
        <textarea name="editFile" rows="5" cols="60"><?php
            echo htmlspecialchars($editFile);
        ?></textarea>

        <hr>

        <h3>Create Text File:</h3>
        <label>New File Name:
            <input type="text" name="newFileName">
        </label>
        <br><br>
        <textarea name="createFile" rows="5" cols="60"></textarea>
        <br>
        <input type="submit" value="Create" name="create">
    </form>
</body>
</html>
