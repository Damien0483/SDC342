<?php
require_once __DIR__ . '/classes/ImageUtilities.php';

$dir     = __DIR__ . '/images/';
$imgName = '';

// View images
if (isset($_POST['view'])) {
    $imgName = $_POST['image_file'] ?? '';
}

// Delete images
if (isset($_POST['delete'])) {
    $fName = $_POST['image_file'] ?? '';
    if ($fName !== '') {
        ImageUtilities::DeleteImageFiles($dir, $fName);
        $imgName = '';
    }
}

// Upload new image
if (isset($_POST['upload'])) {
    if (isset($_FILES['new_file']) && $_FILES['new_file']['error'] === UPLOAD_ERR_OK) {
        $target = $dir . basename($_FILES['new_file']['name']);
        move_uploaded_file($_FILES['new_file']['tmp_name'], $target);
        ImageUtilities::ProcessImage($target);
        $imgName = '';
    }
}

$imageList = ImageUtilities::GetBaseImagesList($dir);
?>
<!DOCTYPE html>
<html>
<head>
    <title>DAMHAR2570 Wk5 Performance Assessment</title>
</head>
<body>
    <h1>Image File Operations</h1>
    <p><a href="index.php">Home</a></p>

    <form method="POST">
        <h3>Image Files:</h3>
        <select name="image_file">
            <?php foreach ($imageList as $file) : ?>
                <option value="<?php echo htmlspecialchars($file); ?>">
                    <?php echo htmlspecialchars($file); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <input type="submit" value="View Images" name="view">
        <input type="submit" value="Delete Image" name="delete">
    </form>

    <hr>

    <h3>Upload Image File:</h3>
    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="new_file" id="new_file" accept=".png,.jpg,.jpeg">
        <input type="submit" value="Upload" name="upload">
    </form>

    <?php if ($imgName !== ''): ?>
        <hr>
        <h4>Original Image:</h4>
        <img src="images/<?php echo htmlspecialchars($imgName); ?>"
             alt="<?php echo htmlspecialchars($imgName); ?>">

        <h4>100px Max Image:</h4>
        <img src="images/100/<?php echo htmlspecialchars($imgName); ?>"
             alt="<?php echo htmlspecialchars($imgName); ?>">

        <h4>250px Max Image:</h4>
        <img src="images/250/<?php echo htmlspecialchars($imgName); ?>"
             alt="<?php echo htmlspecialchars($imgName); ?>">

        <h4>500px Max Image:</h4>
        <img src="images/500/<?php echo htmlspecialchars($imgName); ?>"
             alt="<?php echo htmlspecialchars($imgName); ?>">
    <?php endif; ?>
</body>
</html>
