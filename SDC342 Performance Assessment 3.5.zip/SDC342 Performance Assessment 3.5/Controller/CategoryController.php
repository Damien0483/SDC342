<?php
require_once __DIR__ . '/../models/CategoryDB.php';

class CategoryController {
    public function listCategories(): array {
        return CategoryDB::getAll();
    }
}
