<?php
require_once __DIR__ . '/../models/ProductDB.php';
require_once __DIR__ . '/../models/CategoryDB.php';

class ProductController {

    public function listProducts(): array {
        return ProductDB::getAllWithCategory();
    }

    public function createProduct(int $cat, string $code, string $name, float $price): void {
        $product = new Product(null, $cat, $code, $name, $price);
        ProductDB::create($product);
    }

    public function updateProduct(int $id, int $cat, string $code, string $name, float $price): void {
        $product = new Product($id, $cat, $code, $name, $price);
        ProductDB::update($product);
    }

    public function deleteProduct(int $id): void {
        ProductDB::delete($id);
    }
}
