<?php
class Database {
    private string $host = "localhost";
    private string $db_name = "sdc342_wk3pa";
    private string $username = "root";
    private string $password = "";
    private ?mysqli $conn = null;

    public function getConnection(): ?mysqli {
        if ($this->conn === null) {
            $this->conn = new mysqli(
                $this->host,
                $this->username,
                $this->password,
                $this->db_name
            );

            if ($this->conn->connect_error) {
                $this->conn = null;
            }
        }
        return $this->conn;
    }

    public function getDbName(): string { return $this->db_name; }
    public function getUsername(): string { return $this->username; }
    public function getPassword(): string { return $this->password; }
}
