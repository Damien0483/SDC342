<?php
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Product.php';

class ProductDB {

    public static function getAllWithCategory(): array {
        $db = new Database();
        $conn = $db->getConnection();
        $products = [];

        if ($conn) {
            $sql = "SELECT p.ProductNo, p.ProductCode, p.ProductName, p.ProductPrice,
                           p.CategoryNo, c.CategoryName
                    FROM products p
                    JOIN categories c ON p.CategoryNo = c.CategoryNo
                    ORDER BY p.ProductNo";

            $result = $conn->query($sql);

            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
        }
        return $products;
    }

    public static function create(Product $product): void {
        $db = new Database();
        $conn = $db->getConnection();

        $stmt = $conn->prepare(
            "INSERT INTO products (CategoryNo, ProductCode, ProductName, ProductPrice)
             VALUES (?, ?, ?, ?)"
        );

        $stmt->bind_param(
            "issd",
            $product->getCategoryNo(),
            $product->getProductCode(),
            $product->getProductName(),
            $product->getProductPrice()
        );

        $stmt->execute();
    }

    public static function update(Product $product): void {
        $db = new Database();
        $conn = $db->getConnection();

        $stmt = $conn->prepare(
            "UPDATE products
             SET CategoryNo = ?, ProductCode = ?, ProductName = ?, ProductPrice = ?
             WHERE ProductNo = ?"
        );

        $stmt->bind_param(
            "issdi",
            $product->getCategoryNo(),
            $product->getProductCode(),
            $product->getProductName(),
            $product->getProductPrice(),
            $product->getProductNo()
        );

        $stmt->execute();
    }

    public static function delete(int $id): void {
        $db = new Database();
        $conn = $db->getConnection();

        $stmt = $conn->prepare("DELETE FROM products WHERE ProductNo = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}
