<?php
class Product {
    private ?int $productNo;
    private int $categoryNo;
    private string $productCode;
    private string $productName;
    private float $productPrice;

    public function __construct(?int $productNo, int $categoryNo, string $productCode, string $productName, float $productPrice) {
        $this->productNo = $productNo;
        $this->categoryNo = $categoryNo;
        $this->productCode = $productCode;
        $this->productName = $productName;
        $this->productPrice = $productPrice;
    }

    public function getProductNo(): ?int { return $this->productNo; }
    public function getCategoryNo(): int { return $this->categoryNo; }
    public function getProductCode(): string { return $this->productCode; }
    public function getProductName(): string { return $this->productName; }
    public function getProductPrice(): float { return $this->productPrice; }
}
