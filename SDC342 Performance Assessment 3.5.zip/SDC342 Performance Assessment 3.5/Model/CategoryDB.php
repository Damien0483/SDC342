<?php
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Category.php';

class CategoryDB {
    public static function getAll(): array {
        $db = new Database();
        $conn = $db->getConnection();
        $categories = [];

        if ($conn) {
            $sql = "SELECT CategoryNo, CategoryName FROM categories ORDER BY CategoryName";
            $result = $conn->query($sql);

            while ($row = $result->fetch_assoc()) {
                $categories[] = new Category(
                    (int)$row['CategoryNo'],
                    $row['CategoryName']
                );
            }
        }
        return $categories;
    }
}
