<?php
class Category {
    private int $categoryNo;
    private string $categoryName;

    public function __construct(int $categoryNo, string $categoryName) {
        $this->categoryNo = $categoryNo;
        $this->categoryName = $categoryName;
    }

    public function getCategoryNo(): int { return $this->categoryNo; }
    public function getCategoryName(): string { return $this->categoryName; }
}
