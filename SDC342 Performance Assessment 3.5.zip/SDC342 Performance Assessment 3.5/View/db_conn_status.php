<?php
require_once __DIR__ . '/../models/Database.php';

$db = new Database();
$conn = $db->getConnection();
$status = $conn ? "Successful" : "Unsuccessful";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Name Wk 3 Performance Assessment</title>
</head>
<body>
    <h1>Your Name Database Status</h1>

    <p><strong>Database Name:</strong> <?= $db->getDbName(); ?></p>
    <p><strong>User:</strong> <?= $db->getUsername(); ?></p>
    <p><strong>Password:</strong> <?= $db->getPassword(); ?></p>
    <p><strong>Connection Status:</strong> <?= $status; ?></p>

    <a href="index.php">Return Home</a>
</body>
</html>
