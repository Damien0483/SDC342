<?php
require_once __DIR__ . '/../controllers/ProductController.php';
require_once __DIR__ . '/../controllers/CategoryController.php';

$productController = new ProductController();
$categoryController = new CategoryController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'create') {
        $productController->createProduct(
            (int)$_POST['CategoryNo'],
            $_POST['ProductCode'],
            $_POST['ProductName'],
            (float)$_POST['ProductPrice']
        );
    }

    if ($action === 'update') {
        $productController->updateProduct(
            (int)$_POST['ProductNo'],
            (int)$_POST['CategoryNo'],
            $_POST['ProductCode'],
            $_POST['ProductName'],
            (float)$_POST['ProductPrice']
        );
    }

    if ($action === 'delete') {
        $productController->deleteProduct((int)$_POST['ProductNo']);
    }

    header("Location: products.php");
    exit;
}

$products = $productController->listProducts();
$categories = $categoryController->listCategories();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Name Wk 3 Performance Assessment</title>
</head>
<body>
    <h1>Product Information</h1>

    <a href="index.php">Home</a>

    <h2>Existing Products</h2>
    <table border="1">
        <tr>
            <th>Code</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>

        <?php foreach ($products as $p): ?>
        <tr>
            <form method="post">
                <td><input type="text" name="ProductCode" value="<?= $p['ProductCode']; ?>"></td>
                <td><input type="text" name="ProductName" value="<?= $p['ProductName']; ?>"></td>
                <td>
                    <select name="CategoryNo">
                        <?php foreach ($categories as $c): ?>
                            <option value="<?= $c->getCategoryNo(); ?>"
                                <?= $c->getCategoryNo() === $p['CategoryNo'] ? 'selected' : ''; ?>>
                                <?= $c->getCategoryName(); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td><input type="text" name="ProductPrice" value="<?= $p['ProductPrice']; ?>"></td>

                <td>
                    <input type="hidden" name="ProductNo" value="<?= $p['ProductNo']; ?>">
                    <input type="hidden" name="action" value="update">
                    <button type="submit">Update</button>
                </td>
            </form>

            <td>
                <form method="post">
                    <input type="hidden" name="ProductNo" value="<?= $p['ProductNo']; ?>">
                    <input type="hidden" name="action" value="delete">
                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <h2>Add New Product</h2>
    <form method="post">
        <p>Code: <input type="text" name="ProductCode"></p>
        <p>Name: <input type="text" name="ProductName"></p>
        <p>Category:
            <select name="CategoryNo">
                <?php foreach ($categories as $c): ?>
                    <option value="<?= $c->getCategoryNo(); ?>"><?= $c->getCategoryName(); ?></option>
                <?php endforeach; ?>
            </select>
        </p>
        <p>Price: <input type="text" name="ProductPrice"></p>

        <input type="hidden" name="action" value="create">
        <button type="submit">Add Product</button>
    </form>
</body>
</html>
