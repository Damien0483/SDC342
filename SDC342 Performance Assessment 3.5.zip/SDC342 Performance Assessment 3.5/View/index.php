<!DOCTYPE html>
<html>
<head>
    <title>Your Name Wk 3 Performance Assessment</title>
</head>
<body>
    <h1>Your Name Product Information</h1>

    <nav>
        <a href="index.php">Home</a> |
        <a href="db_conn_status.php">Database Connection Status</a> |
        <a href="products.php">Products</a>
    </nav>
</body>
</html>
