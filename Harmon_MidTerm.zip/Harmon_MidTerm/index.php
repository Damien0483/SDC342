<!DOCTYPE html>
<html>
<head>
    <title>Your Name Midterm Practical</title>
</head>
<body>
    <h1>Your Name Midterm Practical</h1>

    <h2>Main Menu</h2>
    <ul>
        <li><a href="views/display_contacts.php">Display Contacts</a></li>
    </ul>
</body>
</html>
