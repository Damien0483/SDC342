<?php
require_once __DIR__ . '/../controllers/ContactsController.php';

use Controllers\ContactsController;

$controller = new ContactsController();
$errors = [];
$formData = [
    'ContactNo' => '',
    'ContactFirstName' => '',
    'ContactLastName' => '',
    'ContactAddressLine1' => '',
    'ContactAddressLine2' => '',
    'ContactCity' => '',
    'ContactState' => '',
    'ContactZip' => '',
    'ContactBirthdate' => '',
    'ContactEMail' => '',
    'ContactPhone' => '',
    'ContactNotes' => ''
];

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $id = (int)($_POST['ContactNo'] ?? 0);
    if ($id > 0) {
        $controller->deleteContact($id);
    }
    header("Location: display_contacts.php");
    exit;
}

// Handle add/update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save') {
    $formData = $_POST;
    if ($controller->saveContact($_POST, $errors)) {
        header("Location: display_contacts.php");
        exit;
    }
}

// If editing existing contact
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    if ($id > 0) {
        $contact = $controller->getContact($id);
        if ($contact) {
            $formData = $contact;
        }
    }
}

$contacts = $controller->getAllContacts();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Name Midterm Practical</title>
</head>
<body>
    <h1>My Contacts</h1>
    <p><a href="../index.php">Main Menu</a></p>

    <h2>Contact List</h2>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Street Address</th>
            <th>Apt/Office/Bldg</th>
            <th>City</th>
            <th>State</th>
            <th>Zip Code</th>
            <th>DOB</th>
            <th>E-Mail Address</th>
            <th>Phone Number</th>
            <th>Additional Information</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($contacts as $c): ?>
            <tr>
                <td><?= htmlspecialchars($c['ContactNo']); ?></td>
                <td><?= htmlspecialchars($c['ContactLastName'] . ', ' . $c['ContactFirstName']); ?></td>
                <td><?= htmlspecialchars($c['ContactAddressLine1']); ?></td>
                <td><?= htmlspecialchars($c['ContactAddressLine2']); ?></td>
                <td><?= htmlspecialchars($c['ContactCity']); ?></td>
                <td><?= htmlspecialchars($c['ContactState']); ?></td>
                <td><?= htmlspecialchars($c['ContactZip']); ?></td>
                <td><?= htmlspecialchars($c['ContactBirthdate']); ?></td>
                <td><?= htmlspecialchars($c['ContactEMail']); ?></td>
                <td><?= htmlspecialchars($c['ContactPhone']); ?></td>
                <td><?= htmlspecialchars($c['ContactNotes']); ?></td>
                <td>
                    <a href="display_contacts.php?edit=<?= $c['ContactNo']; ?>">Edit</a>
                    <form method="post" action="display_contacts.php" style="display:inline;">
                        <input type="hidden" name="ContactNo" value="<?= $c['ContactNo']; ?>">
                        <input type="hidden" name="action" value="delete">
                        <button type="submit" onclick="return confirm('Delete this contact?');">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h2><?= $formData['ContactNo'] ? 'Update Contact' : 'Add Contact'; ?></h2>
    <form method="post" action="display_contacts.php">
        <input type="hidden" name="ContactNo" value="<?= htmlspecialchars($formData['ContactNo']); ?>">
        <input type="hidden" name="action" value="save">

        <p>
            First Name:
            <input type="text" name="ContactFirstName" value="<?= htmlspecialchars($formData['ContactFirstName']); ?>">
            <?php if (isset($errors['ContactFirstName'])): ?>
                <span style="color:red;"><?= $errors['ContactFirstName']; ?></span>
            <?php endif; ?>
        </p>

        <p>
            Last Name:
            <input type="text" name="ContactLastName" value="<?= htmlspecialchars($formData['ContactLastName']); ?>">
            <?php if (isset($errors['ContactLastName'])): ?>
                <span style="color:red;"><?= $errors['ContactLastName']; ?></span>
            <?php endif; ?>
        </p>

        <p>
            Street Address:
            <input type="text" name="ContactAddressLine1" value="<?= htmlspecialchars($formData['ContactAddressLine1']); ?>">
            <?php if (isset($errors['ContactAddressLine1'])): ?>
                <span style="color:red;"><?= $errors['ContactAddressLine1']; ?></span>
            <?php endif; ?>
        </p>

        <p>
            Apt/Office/Bldg:
            <input type="text" name="ContactAddressLine2" value="<?= htmlspecialchars($formData['ContactAddressLine2']); ?>">
            <?php if (isset($errors['ContactAddressLine2'])): ?>
                <span style="color:red;"><?= $errors['ContactAddressLine2']; ?></span>
            <?php endif; ?>
        </p>

        <p>
            City:
            <input type="text" name="ContactCity" value="<?= htmlspecialchars($formData['ContactCity']); ?>">
            <?php if (isset($errors['ContactCity'])): ?>
                <span style="color:red;"><?= $errors['ContactCity']; ?></span>
            <?php endif; ?>
        </p>

        <p>
            State:
            <input type="text" name="ContactState" maxlength="2" value="<?= htmlspecialchars($formData['ContactState']); ?>">
            <?php if (isset($errors['ContactState'])): ?>
                <span style="color:red;"><?= $errors['ContactState']; ?></span>
            <?php endif; ?>
        </p>

        <p>
            Zip Code:
            <input type="text" name="ContactZip" maxlength="5" value="<?= htmlspecialchars($formData['ContactZip']); ?>">
            <?php if (isset($errors['ContactZip'])): ?>
                <span style="color:red;"><?= $errors['ContactZip']; ?></span>
            <?php endif; ?>
        </p>

        <p>
            DOB:
            <input type="date" name="ContactBirthdate" value="<?= htmlspecialchars($formData['ContactBirthdate']); ?>">
            <?php if (isset($errors['ContactBirthdate'])): ?>
                <span style="color:red;"><?= $errors['ContactBirthdate']; ?></span>
            <?php endif; ?>
        </p>

        <p>
            E-Mail Address:
            <input type="text" name="ContactEMail" value="<?= htmlspecialchars($formData['ContactEMail']); ?>">
            <?php if (isset($errors['ContactEMail'])): ?>
                <span style="color:red;"><?= $errors['ContactEMail']; ?></span>
            <?php endif; ?>
        </p>

        <p>
            Phone Number:
            <input type="text" name="ContactPhone" placeholder="(XXX)XXX-XXXX" value="<?= htmlspecialchars($formData['ContactPhone']); ?>">
            <?php if (isset($errors['ContactPhone'])): ?>
                <span style="color:red;"><?= $errors['ContactPhone']; ?></span>
            <?php endif; ?>
        </p>

        <p>
            Additional Information:
            <input type="text" name="ContactNotes" maxlength="50" value="<?= htmlspecialchars($formData['ContactNotes']); ?>">
            <?php if (isset($errors['ContactNotes'])): ?>
                <span style="color:red;"><?= $errors['ContactNotes']; ?></span>
            <?php endif; ?>
        </p>

        <p>
            <button type="submit"><?= $formData['ContactNo'] ? 'Update Contact' : 'Add Contact'; ?></button>
        </p>
    </form>
</body>
</html>
