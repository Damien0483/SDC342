<?php
namespace Controllers;

class Contact {
    public ?int $ContactNo;
    public string $ContactFirstName;
    public string $ContactLastName;
    public string $ContactAddressLine1;
    public string $ContactAddressLine2;
    public string $ContactCity;
    public string $ContactState;
    public string $ContactZip;
    public string $ContactBirthdate;
    public string $ContactEMail;
    public string $ContactPhone;
    public string $ContactNotes;

    public function __construct(array $data = []) {
        $this->ContactNo          = $data['ContactNo']          ?? null;
        $this->ContactFirstName   = $data['ContactFirstName']   ?? '';
        $this->ContactLastName    = $data['ContactLastName']    ?? '';
        $this->ContactAddressLine1= $data['ContactAddressLine1']?? '';
        $this->ContactAddressLine2= $data['ContactAddressLine2']?? '';
        $this->ContactCity        = $data['ContactCity']        ?? '';
        $this->ContactState       = $data['ContactState']       ?? '';
        $this->ContactZip         = $data['ContactZip']         ?? '';
        $this->ContactBirthdate   = $data['ContactBirthdate']   ?? '';
        $this->ContactEMail       = $data['ContactEMail']       ?? '';
        $this->ContactPhone       = $data['ContactPhone']       ?? '';
        $this->ContactNotes       = $data['ContactNotes']       ?? '';
    }
}
