<?php
namespace Controllers;

require_once __DIR__ . '/../models/ContactsDB.php';
require_once __DIR__ . '/Contact.php';

use Models\ContactsDB;

class ContactsController {

    public function getAllContacts(): array {
        return ContactsDB::getAllContacts();
    }

    public function deleteContact(int $id): bool {
        return ContactsDB::deleteContact($id);
    }

    public function getContact(int $id): ?array {
        return ContactsDB::getContactById($id);
    }

    public function validate(array $data, array &$errors): array {
        $clean = [];

        // First Name
        $clean['ContactFirstName'] = trim($data['ContactFirstName'] ?? '');
        if ($clean['ContactFirstName'] === '' || mb_strlen($clean['ContactFirstName']) < 2) {
            $errors['ContactFirstName'] = 'First name is required and must be at least 2 characters.';
        }

        // Last Name
        $clean['ContactLastName'] = trim($data['ContactLastName'] ?? '');
        if ($clean['ContactLastName'] === '' || mb_strlen($clean['ContactLastName']) < 2) {
            $errors['ContactLastName'] = 'Last name is required and must be at least 2 characters.';
        }

        // Address Line 1
        $clean['ContactAddressLine1'] = trim($data['ContactAddressLine1'] ?? '');
        if ($clean['ContactAddressLine1'] === '') {
            $errors['ContactAddressLine1'] = 'Street address is required.';
        }

        // Address Line 2 (optional)
        $clean['ContactAddressLine2'] = trim($data['ContactAddressLine2'] ?? '');

        // City
        $clean['ContactCity'] = trim($data['ContactCity'] ?? '');
        if ($clean['ContactCity'] === '' || mb_strlen($clean['ContactCity']) < 2) {
            $errors['ContactCity'] = 'City is required and must be at least 2 characters.';
        }

        // State
        $clean['ContactState'] = strtoupper(trim($data['ContactState'] ?? ''));
        if (!preg_match('/^[A-Z]{2}$/', $clean['ContactState'])) {
            $errors['ContactState'] = 'State must be 2 upper-case letters.';
        }

        // Zip
        $clean['ContactZip'] = trim($data['ContactZip'] ?? '');
        if (!preg_match('/^[0-9]{5}$/', $clean['ContactZip'])) {
            $errors['ContactZip'] = 'Zip must be 5 digits.';
        }

        // Birthdate
        $clean['ContactBirthdate'] = trim($data['ContactBirthdate'] ?? '');
        if ($clean['ContactBirthdate'] === '') {
            $errors['ContactBirthdate'] = 'Date of birth is required.';
        }

        // Email
        $clean['ContactEMail'] = trim($data['ContactEMail'] ?? '');
        if (!filter_var($clean['ContactEMail'], FILTER_VALIDATE_EMAIL)) {
            $errors['ContactEMail'] = 'A valid email address is required.';
        }

        // Phone (XXX)XXX-XXXX
        $clean['ContactPhone'] = trim($data['ContactPhone'] ?? '');
        if (!preg_match('/^\(\d{3}\)\d{3}-\d{4}$/', $clean['ContactPhone'])) {
            $errors['ContactPhone'] = 'Phone must be in format (XXX)XXX-XXXX.';
        }

        // Notes (optional, up to 50 chars)
        $clean['ContactNotes'] = trim($data['ContactNotes'] ?? '');
        if (mb_strlen($clean['ContactNotes']) > 50) {
            $errors['ContactNotes'] = 'Notes must be 50 characters or fewer.';
        }

        return $clean;
    }

    public function saveContact(array $data, array &$errors): bool {
        $clean = $this->validate($data, $errors);
        if (!empty($errors)) {
            return false;
        }

        $id = isset($data['ContactNo']) && $data['ContactNo'] !== ''
            ? (int)$data['ContactNo']
            : null;

        if ($id === null) {
            return ContactsDB::addContact($clean);
        } else {
            return ContactsDB::updateContact($id, $clean);
        }
    }
}
