<?php
namespace Models;

require_once __DIR__ . '/Database.php';

class ContactsDB {

    private static function getConn(): ?\mysqli {
        $db = new Database();
        return $db->getConnection();
    }

    public static function getAllContacts(): array {
        $conn = self::getConn();
        $contacts = [];

        if ($conn) {
            $sql = "SELECT * FROM contacts ORDER BY ContactLastName, ContactFirstName";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                $contacts[] = $row;
            }
        }
        return $contacts;
    }

    public static function getContactById(int $id): ?array {
        $conn = self::getConn();
        if (!$conn) return null;

        $stmt = $conn->prepare("SELECT * FROM contacts WHERE ContactNo = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res->fetch_assoc();
        return $row ?: null;
    }

    public static function addContact(array $data): bool {
        $conn = self::getConn();
        if (!$conn) return false;

        $sql = "INSERT INTO contacts
            (ContactFirstName, ContactLastName, ContactAddressLine1, ContactAddressLine2,
             ContactCity, ContactState, ContactZip, ContactBirthdate, ContactEMail,
             ContactPhone, ContactNotes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "sssssssssss",
            $data['ContactFirstName'],
            $data['ContactLastName'],
            $data['ContactAddressLine1'],
            $data['ContactAddressLine2'],
            $data['ContactCity'],
            $data['ContactState'],
            $data['ContactZip'],
            $data['ContactBirthdate'],
            $data['ContactEMail'],
            $data['ContactPhone'],
            $data['ContactNotes']
        );
        return $stmt->execute();
    }

    public static function updateContact(int $id, array $data): bool {
        $conn = self::getConn();
        if (!$conn) return false;

        $sql = "UPDATE contacts
                SET ContactFirstName = ?, ContactLastName = ?, ContactAddressLine1 = ?,
                    ContactAddressLine2 = ?, ContactCity = ?, ContactState = ?, ContactZip = ?,
                    ContactBirthdate = ?, ContactEMail = ?, ContactPhone = ?, ContactNotes = ?
                WHERE ContactNo = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "sssssssssssi",
            $data['ContactFirstName'],
            $data['ContactLastName'],
            $data['ContactAddressLine1'],
            $data['ContactAddressLine2'],
            $data['ContactCity'],
            $data['ContactState'],
            $data['ContactZip'],
            $data['ContactBirthdate'],
            $data['ContactEMail'],
            $data['ContactPhone'],
            $data['ContactNotes'],
            $id
        );
        return $stmt->execute();
    }

    public static function deleteContact(int $id): bool {
        $conn = self::getConn();
        if (!$conn) return false;

        $stmt = $conn->prepare("DELETE FROM contacts WHERE ContactNo = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
