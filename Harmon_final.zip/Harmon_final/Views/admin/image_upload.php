<h2>Upload Image</h2>

<?php if (!empty($message)): ?>
    <p><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<form method="post" action="index.php?action=admin_image_upload" enctype="multipart/form-data">
    <label>Select image:
        <input type="file" name="image" accept="image/*">
    </label>
    <br>
    <button type="submit">Upload</button>
</form>
