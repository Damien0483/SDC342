<h2>Administrator Home</h2>
<ul>
    <li><a href="index.php?action=admin_users">User Management</a></li>
    <li><a href="index.php?action=admin_images">Image File Management</a></li>
</ul>
