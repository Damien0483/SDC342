<h2>Display Image</h2>

<p>Filename: <?= htmlspecialchars($filename) ?></p>

<h3>Original</h3>
<img src="images/<?= htmlspecialchars($filename) ?>" alt="Original">

<h3>Resized (max 200x200)</h3>
<img src="images/200/<?= htmlspecialchars($filename) ?>" alt="Resized">
