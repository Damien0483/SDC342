<h2>User Management</h2>
<p><a href="index.php?action=admin_user_add">Add User</a></p>

<table>
    <tr>
        <th>UserNo</th>
        <th>UserId</th>
        <th>FirstName</th>
        <th>LastName</th>
        <th>HireDate</th>
        <th>EMail</th>
        <th>Extension</th>
        <th>UserLevelNo</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($users as $u): ?>
        <tr>
            <td><?= htmlspecialchars($u['UserNo']) ?></td>
            <td><?= htmlspecialchars($u['UserId']) ?></td>
            <td><?= htmlspecialchars($u['FirstName']) ?></td>
            <td><?= htmlspecialchars($u['LastName']) ?></td>
            <td><?= htmlspecialchars($u['HireDate']) ?></td>
            <td><?= htmlspecialchars($u['EMail']) ?></td>
            <td><?= htmlspecialchars($u['Extension']) ?></td>
            <td><?= htmlspecialchars($u['UserLevelNo']) ?></td>
            <td>
                <a href="index.php?action=admin_user_edit&UserNo=<?= urlencode($u['UserNo']) ?>">Edit</a> |
                <a href="index.php?action=admin_user_delete&UserNo=<?= urlencode($u['UserNo']) ?>"
                   onclick="return confirm('Delete this user?');">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
