<?php
$errors = $errors ?? [];
$old = $old ?? [];
?>
<h2>Add User</h2>

<form method="post" action="index.php?action=admin_user_add">
    <label>User ID:
        <input type="text" name="UserId" value="<?= htmlspecialchars($old['UserId'] ?? '') ?>">
    </label>
    <?php if (!empty($errors['UserId'])): ?>
        <span class="error"><?= htmlspecialchars($errors['UserId']) ?></span>
    <?php endif; ?>
    <br>

    <label>Password:
        <input type="text" name="Password" value="<?= htmlspecialchars($old['Password'] ?? '') ?>">
    </label>
    <?php if (!empty($errors['Password'])): ?>
        <span class="error"><?= htmlspecialchars($errors['Password']) ?></span>
    <?php endif; ?>
    <br>

    <label>First Name:
        <input type="text" name="FirstName" value="<?= htmlspecialchars($old['FirstName'] ?? '') ?>">
    </label>
    <?php if (!empty($errors['FirstName'])): ?>
        <span class="error"><?= htmlspecialchars($errors['FirstName']) ?></span>
    <?php endif; ?>
    <br>

    <label>Last Name:
        <input type="text" name="LastName" value="<?= htmlspecialchars($old['LastName'] ?? '') ?>">
    </label>
    <?php if (!empty($errors['LastName'])): ?>
        <span class="error"><?= htmlspecialchars($errors['LastName']) ?></span>
    <?php endif; ?>
    <br>

    <label>Hire Date:
        <input type="date" name="HireDate" value="<?= htmlspecialchars($old['HireDate'] ?? '') ?>">
    </label>
    <?php if (!empty($errors['HireDate'])): ?>
        <span class="error"><?= htmlspecialchars($errors['HireDate']) ?></span>
    <?php endif; ?>
    <br>

    <label>Email:
        <input type="email" name="EMail" value="<?= htmlspecialchars($old['EMail'] ?? '') ?>">
    </label>
    <?php if (!empty($errors['EMail'])): ?>
        <span class="error"><?= htmlspecialchars($errors['EMail']) ?></span>
    <?php endif; ?>
    <br>

    <label>Extension:
        <input type="text" name="Extension" value="<?= htmlspecialchars($old['Extension'] ?? '') ?>">
    </label>
    <?php if (!empty($errors['Extension'])): ?>
        <span class="error"><?= htmlspecialchars($errors['Extension']) ?></span>
    <?php endif; ?>
    <br>

    <label>User Level:
        <select name="UserLevelNo">
            <option value="">-- Select --</option>
            <?php foreach ($levels as $lvl): ?>
                <option value="<?= htmlspecialchars($lvl['UserLevelNo']) ?>"
                    <?= (isset($old['UserLevelNo']) && (int)$old['UserLevelNo'] === (int)$lvl['UserLevelNo']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($lvl['LevelName']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </label>
    <?php if (!empty($errors['UserLevelNo'])): ?>
        <span class="error"><?= htmlspecialchars($errors['UserLevelNo']) ?></span>
    <?php endif; ?>
    <br>

    <button type="submit">Save</button>
</form>
