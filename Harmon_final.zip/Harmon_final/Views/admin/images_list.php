<h2>Image File Management</h2>

<p><a href="index.php?action=admin_image_upload">Upload Image</a></p>

<table>
    <tr>
        <th>Filename</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($images as $img): ?>
        <tr>
            <td><?= htmlspecialchars($img) ?></td>
            <td>
                <a href="index.php?action=admin_image_display&file=<?= urlencode($img) ?>">View</a> |
                <a href="index.php?action=admin_image_delete&file=<?= urlencode($img) ?>"
                   onclick="return confirm('Delete this image (original and resized)?');">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
