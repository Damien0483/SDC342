<hr>
<p>&copy; <?= date('Y') ?> DAMHAR2570 Final Practical</p>
</body>
</html>
