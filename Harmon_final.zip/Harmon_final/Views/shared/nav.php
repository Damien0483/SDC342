<?php
use Harmon_final\Utilities\Auth;
?>
<nav>
    <?php if (Auth::check()): ?>
        <a href="index.php?action=logout">Logout</a>
        <?php if (Auth::isAdmin()): ?>
            | <a href="index.php?action=admin_home">Admin Home</a>
        <?php endif; ?>
        <?php if (Auth::isTech()): ?>
            | <a href="index.php?action=tech_home">Technician Home</a>
        <?php endif; ?>
    <?php endif; ?>
</nav>
<hr>
