<?php
$old = $old ?? ['filename' => '', 'content' => ''];
?>
<h2>Add Incident File</h2>

<?php if (!empty($message)): ?>
    <p><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<form method="post" action="index.php?action=tech_incident_add">
    <label>Filename (without .txt):
        <input type="text" name="filename" value="<?= htmlspecialchars($old['filename'] ?? '') ?>">
    </label>
    <br>

    <label>Content:<br>
        <textarea name="content" rows="10" cols="60"><?= htmlspecialchars($old['content'] ?? '') ?></textarea>
    </label>
    <br>

    <button type="submit">Save</button>
</form>
