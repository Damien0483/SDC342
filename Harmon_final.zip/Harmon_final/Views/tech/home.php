<h2>Technician Home</h2>
<ul>
    <li><a href="index.php?action=tech_incidents">Incident Management</a></li>
    <li><a href="index.php?action=tech_db_status">Database Connection Status</a></li>
</ul>
