<h2>Edit Incident File: <?= htmlspecialchars($filename) ?></h2>

<?php if (!empty($message)): ?>
    <p><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<form method="post" action="index.php?action=tech_incident_edit&file=<?= urlencode($filename) ?>">
    <label>Content:<br>
        <textarea name="content" rows="10" cols="60"><?= htmlspecialchars($content) ?></textarea>
    </label>
    <br>

    <button type="submit">Save Changes</button>
</form>
