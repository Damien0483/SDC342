<h2>Database Connection Status</h2>

<p>Status: <strong><?= htmlspecialchars($status) ?></strong></p>

<?php if ($status === 'OK'): ?>
    <ul>
        <li>Host Info: <?= htmlspecialchars($info['host_info'] ?? '') ?></li>
        <li>Server Info: <?= htmlspecialchars($info['server_info'] ?? '') ?></li>
        <li>Client Info: <?= htmlspecialchars($info['client_info'] ?? '') ?></li>
    </ul>
<?php else: ?>
    <p>Error: <?= htmlspecialchars($info['error'] ?? 'Unknown error') ?></p>
<?php endif; ?>
