<h2>View Incident File: <?= htmlspecialchars($filename) ?></h2>

<pre><?= htmlspecialchars($content) ?></pre>
