<h2>Incident Files</h2>

<p><a href="index.php?action=tech_incident_add">Add Incident File</a></p>

<table>
    <tr>
        <th>Filename</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($files as $f): ?>
        <tr>
            <td><?= htmlspecialchars($f) ?></td>
            <td>
                <a href="index.php?action=tech_incident_view&file=<?= urlencode($f) ?>">View</a> |
                <a href="index.php?action=tech_incident_edit&file=<?= urlencode($f) ?>">Edit</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
