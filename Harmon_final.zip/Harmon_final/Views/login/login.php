<?php
$errors = $errors ?? [];
$old = $old ?? [];
?>
<h2>Login</h2>

<?php if (!empty($errors['general'])): ?>
    <p class="error"><?= htmlspecialchars($errors['general']) ?></p>
<?php endif; ?>

<form method="post" action="index.php?action=do_login">
    <label>User ID:
        <input type="text" name="UserId" value="<?= htmlspecialchars($old['UserId'] ?? '') ?>">
    </label>
    <?php if (!empty($errors['UserId'])): ?>
        <span class="error"><?= htmlspecialchars($errors['UserId']) ?></span>
    <?php endif; ?>
    <br>

    <label>Password:
        <input type="password" name="Password">
    </label>
    <?php if (!empty($errors['Password'])): ?>
        <span class="error"><?= htmlspecialchars($errors['Password']) ?></span>
    <?php endif; ?>
    <br>

    <button type="submit">Login</button>
</form>
