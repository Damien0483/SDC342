<?php
declare(strict_types=1);

namespace Harmon_final\Utilities;

class Auth
{
    public static function user(): ?array
    {
        return $_SESSION['user'] ?? null;
    }

    public static function check(): bool
    {
        return isset($_SESSION['user']);
    }

    public static function isAdmin(): bool
    {
        return self::check() && (int)$_SESSION['user']['UserLevelNo'] === 1;
    }

    public static function isTech(): bool
    {
        return self::check() && (int)$_SESSION['user']['UserLevelNo'] === 2;
    }

    public static function requireAdmin(): void
    {
        if (!self::isAdmin()) {
            header('Location: index.php?action=login');
            exit;
        }
    }

    public static function requireTech(): void
    {
        if (!self::isTech()) {
            header('Location: index.php?action=login');
            exit;
        }
    }
}
