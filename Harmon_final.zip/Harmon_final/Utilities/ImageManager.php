<?php
declare(strict_types=1);

namespace Harmon_final\Utilities;

class ImageManager
{
    private string $uploadDir;
    private string $thumbDir;

    public function __construct(string $baseDir)
    {
        $this->uploadDir = rtrim($baseDir, '/') . '/images/';
        $this->thumbDir  = $this->uploadDir . '200/';

        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0777, true);
        }
        if (!is_dir($this->thumbDir)) {
            mkdir($this->thumbDir, 0777, true);
        }
    }

    public function upload(array $file): ?string
    {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return null;
        }

        $name = basename($file['name']);
        $target = $this->uploadDir . $name;

        if (!move_uploaded_file($file['tmp_name'], $target)) {
            return null;
        }

        $this->resize($target, $this->thumbDir . $name, 200, 200);

        return $name;
    }

    public function resize(string $source, string $dest, int $maxWidth, int $maxHeight): bool
    {
        [$width, $height, $type] = getimagesize($source);

        $ratio = min($maxWidth / $width, $maxHeight / $height, 1);
        $newWidth  = (int)($width * $ratio);
        $newHeight = (int)($height * $ratio);

        switch ($type) {
            case IMAGETYPE_JPEG:
                $srcImg = imagecreatefromjpeg($source);
                break;
            case IMAGETYPE_PNG:
                $srcImg = imagecreatefrompng($source);
                break;
            case IMAGETYPE_GIF:
                $srcImg = imagecreatefromgif($source);
                break;
            default:
                return false;
        }

        $dstImg = imagecreatetruecolor($newWidth, $newHeight);
        imagecopyresampled($dstImg, $srcImg, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        switch ($type) {
            case IMAGETYPE_JPEG:
                imagejpeg($dstImg, $dest);
                break;
            case IMAGETYPE_PNG:
                imagepng($dstImg, $dest);
                break;
            case IMAGETYPE_GIF:
                imagegif($dstImg, $dest);
                break;
        }

        imagedestroy($srcImg);
        imagedestroy($dstImg);

        return true;
    }

    public function delete(string $filename): void
    {
        $orig = $this->uploadDir . $filename;
        $thumb = $this->thumbDir . $filename;

        if (is_file($orig)) {
            unlink($orig);
        }
        if (is_file($thumb)) {
            unlink($thumb);
        }
    }

    public function listImages(): array
    {
        $files = glob($this->uploadDir . '*.*') ?: [];
        return array_map('basename', $files);
    }

    public function getPaths(string $filename): array
    {
        return [
            'original' => $this->uploadDir . $filename,
            'thumb'    => $this->thumbDir . $filename,
        ];
    }
}
