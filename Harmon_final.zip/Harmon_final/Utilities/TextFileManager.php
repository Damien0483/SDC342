<?php
declare(strict_types=1);

namespace Harmonfinal\Utilities;

class TextFileManager
{
    private string $dir;

    public function __construct(string $baseDir)
    {
        $this->dir = rtrim($baseDir, '/') . '/incidents/';
        if (!is_dir($this->dir)) {
            mkdir($this->dir, 0777, true);
        }
    }

    public function listFiles(): array
    {
        $files = glob($this->dir . '*.txt') ?: [];
        return array_map('basename', $files);
    }

    public function read(string $filename): string
    {
        $path = $this->dir . basename($filename);
        return is_file($path) ? (string)file_get_contents($path) : '';
    }

    public function write(string $filename, string $content): bool
    {
        $path = $this->dir . basename($filename);
        return (bool)file_put_contents($path, $content);
    }

    public function delete(string $filename): void
    {
        $path = $this->dir . basename($filename);
        if (is_file($path)) {
            unlink($path);
        }
    }
}
