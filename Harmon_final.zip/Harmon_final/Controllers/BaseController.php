<?php
declare(strict_types=1);

namespace Harmon_final\Controllers;

class BaseController
{
    protected function render(string $view, array $data = []): void
    {
        extract($data);
        $title = 'DAMHAR2570 Final Practical';

        require __DIR__ . '/../Views/shared/header.php';
        require __DIR__ . '/../Views/shared/nav.php';
        require __DIR__ . '/../Views/' . $view . '.php';
        require __DIR__ . '/../Views/shared/footer.php';
    }

    protected function redirect(string $action): void
    {
        header('Location: index.php?action=' . urlencode($action));
        exit;
    }
}
