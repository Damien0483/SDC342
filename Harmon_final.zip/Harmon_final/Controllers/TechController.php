<?php
declare(strict_types=1);

namespace Harmon_final\Controllers;

use Harmon_final\Models\Database;
use Harmon_final\Utilities\Auth;
use Harmon_final\Utilities\TextFileManager;

class TechController extends BaseController
{
    public function __construct()
    {
        Auth::requireTech();
    }

    public function home(): void
    {
        $this->render('tech/home');
    }

    public function listIncidents(): void
    {
        $tfm = new TextFileManager(__DIR__ . '/../public');
        $files = $tfm->listFiles();
        $this->render('tech/incidents_list', ['files' => $files]);
    }

    public function addIncident(): void
    {
        $tfm = new TextFileManager(__DIR__ . '/../public');
        $message = '';
        $old = ['filename' => '', 'content' => ''];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $filename = trim($_POST['filename'] ?? '');
            $content  = $_POST['content'] ?? '';

            $old = compact('filename', 'content');

            if ($filename === '') {
                $message = 'Filename is required.';
            } else {
                if (substr($filename, -4) !== '.txt') {
                    $filename .= '.txt';
                }
                $tfm->write($filename, $content);
                $message = 'Incident file saved.';
            }
        }

        $this->render('tech/incident_add', [
            'message' => $message,
            'old'     => $old,
        ]);
    }

    public function editIncident(): void
    {
        $tfm = new TextFileManager(__DIR__ . '/../public');
        $filename = $_GET['file'] ?? '';
        $message = '';

        if ($filename === '') {
            $this->redirect('tech_incidents');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $content = $_POST['content'] ?? '';
            $tfm->write($filename, $content);
            $message = 'Incident updated.';
        }

        $content = $tfm->read($filename);

        $this->render('tech/incident_edit', [
            'filename' => $filename,
            'content'  => $content,
            'message'  => $message,
        ]);
    }

    public function viewIncident(): void
    {
        $tfm = new TextFileManager(__DIR__ . '/../public');
        $filename = $_GET['file'] ?? '';

        if ($filename === '') {
            $this->redirect('tech_incidents');
        }

        $content = $tfm->read($filename);

        $this->render('tech/incident_view', [
            'filename' => $filename,
            'content'  => $content,
        ]);
    }

    public function dbStatus(): void
    {
        $info = [];
        $status = 'OK';

        try {
            $db = Database::getConnection();
            $info['host_info'] = $db->host_info;
            $info['server_info'] = $db->server_info;
            $info['client_info'] = $db->client_info;
        } catch (\Throwable $e) {
            $status = 'FAIL';
            $info['error'] = $e->getMessage();
        }

        $this->render('tech/db_status', [
            'status' => $status,
            'info'   => $info,
        ]);
    }
}
