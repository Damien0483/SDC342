<?php
declare(strict_types=1);

namespace Harmon_final\Controllers;

use Harmon_final\Models\User;
use Harmon_final\Utilities\Auth;

class LoginController extends BaseController
{
    public function showLoginForm(): void
    {
        $this->render('login/login', ['errors' => [], 'old' => []]);
    }

    public function login(): void
    {
        $userId = $_POST['UserId'] ?? '';
        $password = $_POST['Password'] ?? '';

        $errors = [];
        if ($userId === '') {
            $errors['UserId'] = 'User ID is required.';
        }
        if ($password === '') {
            $errors['Password'] = 'Password is required.';
        }

        if ($errors) {
            $this->render('login/login', ['errors' => $errors, 'old' => $_POST]);
            return;
        }

        $userModel = new User();
        $user = $userModel->findByUserId($userId);

        if (!$user || $user['Password'] !== $password) {
            $errors['general'] = 'Invalid credentials.';
            $this->render('login/login', ['errors' => $errors, 'old' => $_POST]);
            return;
        }

        $_SESSION['user'] = [
            'UserNo'      => $user['UserNo'],
            'UserId'      => $user['UserId'],
            'FirstName'   => $user['FirstName'],
            'LastName'    => $user['LastName'],
            'UserLevelNo' => $user['UserLevelNo'],
        ];

        if ((int)$user['UserLevelNo'] === 1) {
            $this->redirect('admin_home');
        } elseif ((int)$user['UserLevelNo'] === 2) {
            $this->redirect('tech_home');
        } else {
            $this->redirect('login');
        }
    }

    public function logout(): void
    {
        session_destroy();
        $this->redirect('login');
    }
}
