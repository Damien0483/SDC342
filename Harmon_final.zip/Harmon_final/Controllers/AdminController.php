<?php
declare(strict_types=1);

namespace Harmon_final\Controllers;

use Harmon_final\Models\User;
use Harmon_final\Models\UserLevel;
use Harmon_final\Utilities\Auth;
use Harmon_final\Utilities\Validator;
use Harmon_final\Utilities\ImageManager;

class AdminController extends BaseController
{
    public function __construct()
    {
        Auth::requireAdmin();
    }

    public function home(): void
    {
        $this->render('admin/home');
    }

    public function listUsers(): void
    {
        $userModel = new User();
        $users = $userModel->getAll();
        $this->render('admin/users_list', ['users' => $users]);
    }

    public function addUser(): void
    {
        $userLevelModel = new UserLevel();
        $levels = $userLevelModel->getAll();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'UserId'      => $_POST['UserId'] ?? '',
                'Password'    => $_POST['Password'] ?? '',
                'FirstName'   => $_POST['FirstName'] ?? '',
                'LastName'    => $_POST['LastName'] ?? '',
                'HireDate'    => $_POST['HireDate'] ?? '',
                'EMail'       => $_POST['EMail'] ?? '',
                'Extension'   => $_POST['Extension'] ?? '',
                'UserLevelNo' => $_POST['UserLevelNo'] ?? '',
            ];

            $errors = Validator::validateUser($data);

            if (empty($errors)) {
                $userModel = new User();
                $userModel->create($data);
                $this->redirect('admin_users');
                return;
            }

            $this->render('admin/user_add', [
                'errors' => $errors,
                'old'    => $data,
                'levels' => $levels,
            ]);
            return;
        }

        $this->render('admin/user_add', [
            'errors' => [],
            'old'    => [],
            'levels' => $levels,
        ]);
    }

    public function editUser(): void
    {
        $userNo = isset($_GET['UserNo']) ? (int)$_GET['UserNo'] : 0;
        $userModel = new User();
        $user = $userModel->findByUserNo($userNo);

        if (!$user) {
            $this->redirect('admin_users');
        }

        $userLevelModel = new UserLevel();
        $levels = $userLevelModel->getAll();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'UserId'      => $_POST['UserId'] ?? '',
                'Password'    => $_POST['Password'] ?? '',
                'FirstName'   => $_POST['FirstName'] ?? '',
                'LastName'    => $_POST['LastName'] ?? '',
                'HireDate'    => $_POST['HireDate'] ?? '',
                'EMail'       => $_POST['EMail'] ?? '',
                'Extension'   => $_POST['Extension'] ?? '',
                'UserLevelNo' => $_POST['UserLevelNo'] ?? '',
            ];

            $errors = Validator::validateUser($data);

            if (empty($errors)) {
                $userModel->update($userNo, $data);
                $this->redirect('admin_users');
                return;
            }

            $this->render('admin/user_edit', [
                'errors' => $errors,
                'old'    => $data,
                'levels' => $levels,
                'userNo' => $userNo,
            ]);
            return;
        }

        $this->render('admin/user_edit', [
            'errors' => [],
            'old'    => $user,
            'levels' => $levels,
            'userNo' => $userNo,
        ]);
    }

    public function deleteUser(): void
    {
        $userNo = isset($_GET['UserNo']) ? (int)$_GET['UserNo'] : 0;
        if ($userNo > 0) {
            $userModel = new User();
            $userModel->delete($userNo);
        }
        $this->redirect('admin_users');
    }

    public function listImages(): void
    {
        $imgManager = new ImageManager(__DIR__ . '/../public');
        $images = $imgManager->listImages();
        $this->render('admin/images_list', ['images' => $images]);
    }

    public function uploadImage(): void
    {
        $imgManager = new ImageManager(__DIR__ . '/../public');
        $message = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
            $filename = $imgManager->upload($_FILES['image']);
            if ($filename) {
                $message = 'Image uploaded successfully.';
            } else {
                $message = 'Image upload failed.';
            }
        }

        $this->render('admin/image_upload', ['message' => $message]);
    }

    public function displayImage(): void
    {
        $filename = $_GET['file'] ?? '';
        if ($filename === '') {
            $this->redirect('admin_images');
        }

        $imgManager = new ImageManager(__DIR__ . '/../public');
        $paths = $imgManager->getPaths($filename);

        $this->render('admin/image_display', [
            'filename' => $filename,
            'paths'    => $paths,
        ]);
    }

    public function deleteImage(): void
    {
        $filename = $_GET['file'] ?? '';
        if ($filename !== '') {
            $imgManager = new ImageManager(__DIR__ . '/../public');
            $imgManager->delete($filename);
        }
        $this->redirect('admin_images');
    }
}
