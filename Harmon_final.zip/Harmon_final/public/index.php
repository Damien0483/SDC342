<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../Controllers/BaseController.php';
require_once __DIR__ . '/../Controllers/LoginController.php';
require_once __DIR__ . '/../Controllers/AdminController.php';
require_once __DIR__ . '/../Controllers/TechController.php';
require_once __DIR__ . '/../Models/Database.php';
require_once __DIR__ . '/../Models/BaseModel.php';
require_once __DIR__ . '/../Models/User.php';
require_once __DIR__ . '/../Models/UserLevel.php';
require_once __DIR__ . '/../Utilities/Auth.php';
require_once __DIR__ . '/../Utilities/Validator.php';
require_once __DIR__ . '/../Utilities/ImageManager.php';
require_once __DIR__ . '/../Utilities/TextFileManager.php';

use Harmon_final\Controllers\LoginController;
use Harmon_final\Controllers\AdminController;
use Harmon_final\Controllers\TechController;

$action = $_GET['action'] ?? 'login';

switch ($action) {
    case 'login':
        (new LoginController())->showLoginForm();
        break;
    case 'do_login':
        (new LoginController())->login();
        break;
    case 'logout':
        (new LoginController())->logout();
        break;

    // Admin
    case 'admin_home':
        (new AdminController())->home();
        break;
    case 'admin_users':
        (new AdminController())->listUsers();
        break;
    case 'admin_user_add':
        (new AdminController())->addUser();
        break;
    case 'admin_user_edit':
        (new AdminController())->editUser();
        break;
    case 'admin_user_delete':
        (new AdminController())->deleteUser();
        break;

    case 'admin_images':
        (new AdminController())->listImages();
        break;
    case 'admin_image_upload':
        (new AdminController())->uploadImage();
        break;
    case 'admin_image_display':
        (new AdminController())->displayImage();
        break;
    case 'admin_image_delete':
        (new AdminController())->deleteImage();
        break;

    // Tech
    case 'tech_home':
        (new TechController())->home();
        break;
    case 'tech_incidents':
        (new TechController())->listIncidents();
        break;
    case 'tech_incident_add':
        (new TechController())->addIncident();
        break;
    case 'tech_incident_edit':
        (new TechController())->editIncident();
        break;
    case 'tech_incident_view':
        (new TechController())->viewIncident();
        break;
    case 'tech_db_status':
        (new TechController())->dbStatus();
        break;

    default:
        (new LoginController())->showLoginForm();
        break;
}
