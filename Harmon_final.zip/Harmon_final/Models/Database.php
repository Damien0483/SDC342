<?php
declare(strict_types=1);

namespace Harmon_final\Models;

use mysqli;
use RuntimeException;

class Database
{
    private static ?mysqli $connection = null;

    public static function getConnection(): mysqli
    {
        if (self::$connection === null) {
            $host = 'localhost';
            $user = 'your_db_user';
            $pass = 'your_db_password';
            $name = 'sdc342_wk5final';

            self::$connection = new mysqli($host, $user, $pass, $name);

            if (self::$connection->connect_error) {
                throw new RuntimeException('Database connection failed: ' . self::$connection->connect_error);
            }

            self::$connection->set_charset('utf8mb4');
        }

        return self::$connection;
    }
}

