<?php
declare(strict_types=1);

namespace Harmon_final\Models;

class User extends BaseModel
{
    public function findByUserId(string $userId): ?array
    {
        $sql = 'SELECT * FROM users WHERE UserId = ?';
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('s', $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();

        return $row ?: null;
    }

    public function getAll(): array
    {
        $result = $this->db->query('SELECT * FROM users ORDER BY LastName, FirstName');
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function create(array $data): bool
    {
        $sql = 'INSERT INTO users (UserId, Password, FirstName, LastName, HireDate, EMail, Extension, UserLevelNo)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param(
            'ssssssii',
            $data['UserId'],
            $data['Password'],
            $data['FirstName'],
            $data['LastName'],
            $data['HireDate'],
            $data['EMail'],
            $data['Extension'],
            $data['UserLevelNo']
        );
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    public function findByUserNo(int $userNo): ?array
    {
        $sql = 'SELECT * FROM users WHERE UserNo = ?';
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('i', $userNo);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();

        return $row ?: null;
    }

    public function update(int $userNo, array $data): bool
    {
        $sql = 'UPDATE users
                SET UserId = ?, Password = ?, FirstName = ?, LastName = ?, HireDate = ?, EMail = ?, Extension = ?, UserLevelNo = ?
                WHERE UserNo = ?';
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param(
            'ssssssiii',
            $data['UserId'],
            $data['Password'],
            $data['FirstName'],
            $data['LastName'],
            $data['HireDate'],
            $data['EMail'],
            $data['Extension'],
            $data['UserLevelNo'],
            $userNo
        );
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    public function delete(int $userNo): bool
    {
        $sql = 'DELETE FROM users WHERE UserNo = ?';
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('i', $userNo);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }
}
