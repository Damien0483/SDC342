<?php
declare(strict_types=1);

namespace Harmon_final\Models;

class UserLevel extends BaseModel
{
    public function getAll(): array
    {
        $result = $this->db->query('SELECT * FROM user_levels ORDER BY UserLevelNo');
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
