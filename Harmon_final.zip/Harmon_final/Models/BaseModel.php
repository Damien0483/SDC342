<?php
declare(strict_types=1);

namespace Harmon_final\Models;

use mysqli;

abstract class BaseModel
{
    protected mysqli $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }
}
