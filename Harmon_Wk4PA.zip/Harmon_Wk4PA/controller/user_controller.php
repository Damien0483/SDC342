<?php
require_once(__DIR__ . '/../model/user_db.php');
require_once(__DIR__ . '/../model/user.php');

class UserController {
    private static function rowToUser($row) {
        return new User(
            $row['FirstName'],
            $row['LastName'],
            $row['EMail'],
            $row['Password'],
            $row['RegistrationDate'],
            $row['UserLevel'],
            $row['UserId']
        );
    }

    // Check login credentials - return user level if valid, false otherwise
    public static function validUser($email, $password) {
        $row = UsersDB::getUserByEMail($email);
        if ($row) {
            $user = self::rowToUser($row);
            // plain-text compare for assignment
            if ($user->getPassword() === $password) {
                return $user->getUserLevel();
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    // For View Accounts page
    public static function getAllUsers() {
        return UsersDB::getAllUsers();
    }
}
