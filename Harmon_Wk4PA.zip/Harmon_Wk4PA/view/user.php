<?php
session_start();
require_once(__DIR__ . '/../util/security.php');

Security::checkAuthority('user');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
    <title>Damien Wk 4 Performance Assessment</title>
</head>
<body>
    <h1>Menu</h1>
    <form method="POST">
        <p><a href="products.php">View Products</a></p>
        <input type="submit" value="Logout" name="logout">
    </form>
</body>
</html>
