<?php
session_start();
require_once(__DIR__ . '/../util/security.php');

Security::checkAuthority('tech');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
    <title>Damien Wk 4 Performance Assessment</title>
</head>
<body>
    <h1>Open Incidents</h1>
    <p><a href="tech.php">Home</a></p>
    <form method="POST">
        <input type="submit" value="Logout" name="logout">
    </form>

    <h2>Incident List</h2>
    <p>(Placeholder content for open incidents.)</p>
</body>
</html>
