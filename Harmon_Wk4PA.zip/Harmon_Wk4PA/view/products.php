<?php
session_start();
require_once(__DIR__ . '/../util/security.php');

Security::checkAuthority('user');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
    <title>Damien Wk 4 Performance Assessment</title>
</head>
<body>
    <h1>Products</h1>
    <p><a href="user.php">Home</a></p>
    <form method="POST">
        <input type="submit" value="Logout" name="logout">
    </form>

    <h2>Product List</h2>
    <p>(Placeholder content for products.)</p>
</body>
</html>
