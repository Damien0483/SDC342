<?php
session_start();
require_once(__DIR__ . '/../util/security.php');

Security::checkAuthority('tech');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
    <title>Damien Wk 4 Performance Assessment</title>
</head>
<body>
    <h1>Manage Incidents</h1>
    <form method="POST">
        <p><a href="open_incidents.php">View Open Incidents</a></p>
        <input type="submit" value="Logout" name="logout">
    </form>
</body>
</html>
