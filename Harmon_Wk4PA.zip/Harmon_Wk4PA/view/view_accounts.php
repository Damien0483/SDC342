<?php
session_start();
require_once(__DIR__ . '/../util/security.php');
require_once(__DIR__ . '/../controller/user_controller.php');

Security::checkAuthority('admin');

if (isset($_POST['logout'])) {
    Security::logout();
}

$users = UserController::getAllUsers();
?>
<html>
<head>
    <title>Damien Wk 4 Performance Assessment</title>
</head>
<body>
    <h1>View User Accounts</h1>
    <p><a href="admin.php">Home</a></p>
    <form method="POST">
        <input type="submit" value="Logout" name="logout">
    </form>

    <h2>Accounts</h2>
    <table border="1" cellpadding="5">
        <tr>
            <th>UserId</th>
            <th>Name</th>
            <th>Email</th>
            <th>User Level</th>
        </tr>
        <?php foreach ($users as $u): ?>
            <tr>
                <td><?php echo htmlspecialchars($u['UserId']); ?></td>
                <td><?php echo htmlspecialchars($u['FirstName'] . ' ' . $u['LastName']); ?></td>
                <td><?php echo htmlspecialchars($u['EMail']); ?></td>
                <td><?php echo htmlspecialchars($u['UserLevel']); ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
