<?php
session_start();
require_once(__DIR__ . '/../util/security.php');

Security::checkAuthority('admin');

if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
    <title>Damien Wk 4 Performance Assessment</title>
</head>
<body>
    <h1>Administrator Options</h1>
    <form method="POST">
        <p><a href="view_accounts.php">View Accounts</a></p>
        <input type="submit" value="Logout" name="logout">
    </form>
</body>
</html>
