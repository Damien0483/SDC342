<?php
require_once(__DIR__ . '/database.php');
require_once(__DIR__ . '/user.php');

class UsersDB {
    // Get a user by their e-mail address
    public static function getUserByEMail($email) {
        $db = new Database();
        $dbConn = $db->getDbConn();

        if ($dbConn) {
            // use prepared statement to avoid injection
            $query = "SELECT * FROM users WHERE EMail = ?";
            $stmt = $dbConn->prepare($query);
            if (!$stmt) {
                return false;
            }
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $stmt->close();

            if ($row) {
                return $row;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static function getAllUsers() {
        $db = new Database();
        $dbConn = $db->getDbConn();

        if ($dbConn) {
            $query = "SELECT * FROM users ORDER BY LastName, FirstName";
            $result = $dbConn->query($query);
            if (!$result) {
                return [];
            }

            $users = [];
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
            return $users;
        } else {
            return [];
        }
    }
}
