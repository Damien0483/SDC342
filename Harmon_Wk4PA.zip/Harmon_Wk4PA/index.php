<?php
session_start();

require_once(__DIR__ . '/controller/user_controller.php');
require_once(__DIR__ . '/util/security.php');

Security::checkHTTPS();

$login_msg = isset($_SESSION['logout_msg']) ? $_SESSION['logout_msg'] : '';
unset($_SESSION['logout_msg']);

if (isset($_POST['email']) && isset($_POST['pw'])) {
    $email = trim($_POST['email']);
    $pw    = trim($_POST['pw']);

    $user_level = UserController::validUser($email, $pw);

    // reset all roles
    $_SESSION['admin'] = false;
    $_SESSION['user']  = false;
    $_SESSION['tech']  = false;

    if ($user_level === '1') {
        $_SESSION['admin'] = true;
        header("Location: view/admin.php");
        exit();
    } elseif ($user_level === '2') {
        $_SESSION['user'] = true;
        header("Location: view/user.php");
        exit();
    } elseif ($user_level === '3') {
        $_SESSION['tech'] = true;
        header("Location: view/tech.php");
        exit();
    } else {
        $login_msg = 'Login credentials were incorrect. Please try again.';
    }
}
?>
<html>
<head>
    <title>Damien Wk 4 Performance Assessment</title>
</head>
<body>
    <h1>Damien Application Login</h1>
    <h2>Login</h2>
    <form method="POST">
        <h3>User ID (e-mail): <input type="text" name="email"></h3>
        <h3>Password: <input type="password" name="pw"></h3>
        <input type="submit" value="Login" name="login">
    </form>
    <h2><?php echo htmlspecialchars($login_msg); ?></h2>
</body>
</html>
